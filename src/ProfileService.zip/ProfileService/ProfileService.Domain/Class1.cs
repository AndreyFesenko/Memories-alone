﻿namespace ProfileService.Domain;

public class Class1
{

}
