﻿namespace ProfileService.Application;

public class Class1
{

}
