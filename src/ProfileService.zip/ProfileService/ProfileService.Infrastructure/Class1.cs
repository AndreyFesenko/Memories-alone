﻿namespace ProfileService.Infrastructure;

public class Class1
{

}
