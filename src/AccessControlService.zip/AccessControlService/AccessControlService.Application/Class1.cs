﻿namespace AccessControlService.Application;

public class Class1
{

}
