﻿using System;
using MediatR;
using MemoryArchiveService.Application.DTOs;

namespace MemoryArchiveService.Application.Queries;

public sealed record GetMediaQuery(Guid Id) : IRequest<MediaFileDto>;
