﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using MemoryArchiveService.Application.Abstractions;
using MemoryArchiveService.Application.DTOs;
using MemoryArchiveService.Application.Queries;

namespace MemoryArchiveService.Application.Handlers;

public sealed class GetMediaQueryHandler : IRequestHandler<GetMediaQuery, MediaFileDto>
{
    private readonly IMediaReadStore _store;

    public GetMediaQueryHandler(IMediaReadStore store) => _store = store;

    public async Task<MediaFileDto> Handle(GetMediaQuery request, CancellationToken ct)
    {
        var dto = await _store.GetByIdAsync(request.Id, ct);
        if (dto is null)
            throw new KeyNotFoundException($"Media {request.Id} not found");
        return dto;
    }
}
