﻿// src/MemoryArchiveService/MemoryArchiveService.Application/Handlers/CreateMemoryCommandHandler.cs
using MediatR;
using MemoryArchiveService.Application.Commands;
using MemoryArchiveService.Application.DTOs;
using MemoryArchiveService.Application.Interfaces;
using MemoryArchiveService.Domain.Entities;

namespace MemoryArchiveService.Application.Handlers;

public class CreateMemoryCommandHandler : IRequestHandler<CreateMemoryCommand, MemoryDto>
{
    private readonly IMemoryRepository _repo;
    private readonly ITagRepository _tags;
    private readonly IEventBus _eventBus;
    private readonly IStorageService _storage;

    public CreateMemoryCommandHandler(
        IMemoryRepository repo,
        ITagRepository tags,
        IEventBus eventBus,
        IStorageService storage)
    {
        _repo = repo;
        _tags = tags;
        _eventBus = eventBus;
        _storage = storage;
    }

    public async Task<MemoryDto> Handle(CreateMemoryCommand request, CancellationToken ct)
    {
        // --- Валидация простых полей ---
        if (string.IsNullOrWhiteSpace(request.OwnerId))
            throw new ArgumentException("OwnerId is required");
        if (!Guid.TryParse(request.OwnerId, out var ownerId))
            throw new ArgumentException("OwnerId must be a valid GUID");

        var contentType = string.IsNullOrWhiteSpace(request.ContentType)
            ? "application/octet-stream"
            : request.ContentType;

        // безопасное/уникальное имя файла
        var safeFileName = string.IsNullOrWhiteSpace(request.FileName)
            ? $"{Guid.NewGuid():N}"
            : request.FileName.Trim();

        // --- Загрузка бинарника в сторадж (стоардж сам буферизует поток) ---
        // ВАЖНО: не закрываем stream до завершения UploadAsync.
        var storageUrl = await _storage.UploadAsync(
            request.FileStream,
            safeFileName,
            contentType,
            ct
        );

        // --- Тип медиа ---
        var mediaType = Enum.TryParse<MediaType>(request.MediaType, ignoreCase: true, out var parsedType)
            ? parsedType
            : MediaType.Image;

        // --- Access level ---
        var accessLevel = Enum.TryParse(request.AccessLevel, ignoreCase: true, out AccessLevel parsedLevel)
            ? parsedLevel
            : AccessLevel.Private;

        // --- Сборка доменной модели ---
        var memory = new Memory
        {
            Id = Guid.NewGuid(),
            OwnerId = ownerId,
            Title = request.Title,
            Description = request.Description,
            CreatedAt = DateTime.UtcNow,
            AccessLevel = accessLevel,
            Tags = new List<Tag>(),
            MediaFiles = new List<MediaFile>
            {
                new MediaFile
                {
                    Id = Guid.NewGuid(),
                    FileName = safeFileName,
                    Url = storageUrl,
                    StorageUrl = storageUrl,
                    MediaType = mediaType,
                    OwnerId = request.OwnerId, // если в MediaFile OwnerId — string, оставляем как есть
                    CreatedAt = DateTime.UtcNow
                }
            }
        };

        // --- Теги (без дублей) ---
        if (request.Tags is { Count: > 0 })
        {
            foreach (var tagName in request.Tags
                         .Where(t => !string.IsNullOrWhiteSpace(t))
                         .Select(t => t.Trim())
                         .Distinct(StringComparer.OrdinalIgnoreCase))
            {
                var existing = await _tags.GetByNameAsync(tagName, ct);
                if (existing is not null)
                {
                    memory.Tags.Add(existing);
                }
                else
                {
                    memory.Tags.Add(new Tag { Id = Guid.NewGuid(), Name = tagName });
                }
            }
        }

        // --- Persist ---
        await _repo.AddAsync(memory, ct);

        // --- Event ---
        await _eventBus.PublishAsync(new
        {
            Event = "MemoryCreated",
            MemoryId = memory.Id,
            OwnerId = memory.OwnerId,
            Title = memory.Title,
            CreatedAt = memory.CreatedAt
        }, ct);

        // --- DTO ---
        return new MemoryDto
        {
            Id = memory.Id,
            OwnerId = memory.OwnerId,
            Title = memory.Title,
            Description = memory.Description,
            CreatedAt = memory.CreatedAt,
            AccessLevel = memory.AccessLevel.ToString(),
            Tags = memory.Tags.Select(t => t.Name).ToList()
        };
    }
}
