﻿using System;
using System.Threading;
using System.Threading.Tasks;
using MemoryArchiveService.Application.DTOs;

namespace MemoryArchiveService.Application.Abstractions;

public interface IMediaReadStore
{
    Task<MediaFileDto?> GetByIdAsync(Guid id, CancellationToken ct);
}
