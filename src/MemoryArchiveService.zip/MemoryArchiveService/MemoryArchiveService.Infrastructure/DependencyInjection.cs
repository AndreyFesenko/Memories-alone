﻿// src/MemoryArchiveService/MemoryArchiveService.Infrastructure/DependencyInjection.cs
using Amazon.S3;
using MemoryArchiveService.Application.Abstractions;            // <— абстракции из Application
using MemoryArchiveService.Application.Interfaces;
using MemoryArchiveService.Infrastructure.Persistence;
using MemoryArchiveService.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
// Если у вас есть репозитории и шина событий с интерфейсами в Application.Abstractions — подключите их здесь:
// using MemoryArchiveService.Application.Abstractions.Repositories;
// using MemoryArchiveService.Application.Abstractions.Messaging;

namespace MemoryArchiveService.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration config)
    {
        // ----- DbContext (PostgreSQL) -----
        var conn =
            config.GetConnectionString("DefaultConnection") ??
            config.GetConnectionString("Default") ??
            config["Database:ConnectionString"];

        services.AddDbContext<MemoryArchiveDbContext>(opts =>
        {
            opts.UseNpgsql(conn, npg =>
            {
                // история миграций в схеме memory
                npg.MigrationsHistoryTable("__EFMigrationsHistory", "memory");
            });
        });

        // ----- S3 (Supabase совместимый) -----
        services.AddSingleton<IAmazonS3>(sp =>
        {
            var cfg = sp.GetRequiredService<IConfiguration>().GetSection("Supabase:S3");

            var serviceUrl = cfg["Endpoint"];   // напр.: https://<project>.supabase.co/storage/v1/s3
            var access = cfg["AccessKey"];  // S3 Access Key из Supabase
            var secret = cfg["SecretKey"];  // S3 Secret Key

            var s3cfg = new AmazonS3Config
            {
                ServiceURL = serviceUrl,
                ForcePathStyle = true,
                // у Supabase регион не критичен, но AWS SDK требует строку
                AuthenticationRegion = "ap-southeast-1"
            };

            return new AmazonS3Client(access, secret, s3cfg);
        });

        // ----- Реализации абстракций уровня Application -----
        // Хранилище/рид-стор для чтения медиа (используется GetMediaQueryHandler)
        services.AddScoped<IMediaReadStore, MediaReadStore>();

        // Публичные URL для отдачи ссылок (если используете)
        services.AddSingleton<IPublicUrlResolver, SupabasePublicUrlResolver>();

        // Хранилище на базе IAmazonS3 (если используется в командах/хендлерах)
        services.AddScoped<IStorageService, SupabaseStorageService>();

        // ----- Репозитории (если у вас они есть и их интерфейсы лежат в Application.Abstractions) -----
        // services.AddScoped<IMemoryRepository, MemoryRepository>();
        // services.AddScoped<IMediaRepository,  MediaRepository>();
        // services.AddScoped<ITagRepository,    TagRepository>();

        // ----- Event Bus / RabbitMQ (если интерфейсы в Application.Abstractions) -----
        // services.Configure<RabbitMqOptions>(config.GetSection("RabbitMq"));
        // services.AddSingleton<IEventBus, RabbitMqEventBus>();

        return services;
    }
}
