﻿// src/MemoryArchiveService/MemoryArchiveService.Infrastructure/Services/SupabaseStorageService.cs
using System.Net;
using Amazon.S3;
using Amazon.S3.Model;
using MemoryArchiveService.Application.Interfaces;
using Microsoft.Extensions.Configuration;

namespace MemoryArchiveService.Infrastructure.Services;

public class SupabaseStorageService : IStorageService
{
    private readonly IAmazonS3 _s3;
    private readonly string _bucket;
    private readonly string _endpoint; // для построения URL
    private readonly SemaphoreSlim _ensureOnce = new(1, 1);
    private bool _bucketEnsured;

    public SupabaseStorageService(IAmazonS3 s3, IConfiguration cfg)
    {
        _s3 = s3;
        _bucket = cfg["Supabase:S3:Bucket"] ?? throw new InvalidOperationException("Supabase:S3:Bucket is missing");
        _endpoint = cfg["Supabase:S3:Endpoint"]
                    ?? throw new InvalidOperationException("Supabase:S3:Endpoint is missing");
    }

    public async Task<string> UploadAsync(Stream stream, string fileName, string contentType, CancellationToken ct = default)
    {
        await EnsureBucketAsync(ct);

        if (string.IsNullOrWhiteSpace(fileName))
            fileName = $"{Guid.NewGuid():N}";

        if (string.IsNullOrWhiteSpace(contentType))
            contentType = "application/octet-stream";

        // На всякий случай перемотать, если можно
        if (stream.CanSeek) stream.Position = 0;

        var put = new PutObjectRequest
        {
            BucketName = _bucket,
            Key = fileName,
            InputStream = stream,
            ContentType = contentType,
            // Метаданные по желанию:
            // CannedACL = S3CannedACL.PublicRead    // если хочешь публичный доступ
        };

        var resp = await _s3.PutObjectAsync(put, ct);

        // Построим path-style URL, который ожидаем при ForcePathStyle=true
        // Пример: https://<endpoint>/<bucket>/<key>
        // В appsettings Endpoint должен быть полным URL, как у тебя:
        // https://...supabase.co/storage/v1/s3
        var url = $"{_endpoint.TrimEnd('/')}/{_bucket}/{Uri.EscapeDataString(fileName)}";
        return url;
    }

    public async Task<Stream> DownloadAsync(string fileName, CancellationToken ct = default)
    {
        await EnsureBucketAsync(ct);

        var get = new GetObjectRequest
        {
            BucketName = _bucket,
            Key = fileName
        };

        using var resp = await _s3.GetObjectAsync(get, ct);
        var ms = new MemoryStream();
        await resp.ResponseStream.CopyToAsync(ms, ct);
        ms.Position = 0;
        return ms;
    }

    public async Task DeleteAsync(string fileName, CancellationToken ct = default)
    {
        await EnsureBucketAsync(ct);

        var del = new DeleteObjectRequest
        {
            BucketName = _bucket,
            Key = fileName
        };
        await _s3.DeleteObjectAsync(del, ct);
    }

    private async Task EnsureBucketAsync(CancellationToken ct)
    {
        if (_bucketEnsured) return;

        await _ensureOnce.WaitAsync(ct);
        try
        {
            if (_bucketEnsured) return;

            // Самый дешёвый способ — HeadBucket (если нет прав — получим 404/403)
            try
            {
                await _s3.GetBucketLocationAsync(new GetBucketLocationRequest
                {
                    BucketName = _bucket
                }, ct);

                _bucketEnsured = true;
                return;
            }
            catch (AmazonS3Exception ex) when (ex.StatusCode is HttpStatusCode.NotFound)
            {
                // создадим бакет, если его нет (некоторые S3-совместимые сервисы требуют регион/локацию)
                await _s3.PutBucketAsync(new PutBucketRequest
                {
                    BucketName = _bucket
                }, ct);

                _bucketEnsured = true;
                return;
            }
        }
        finally
        {
            _ensureOnce.Release();
        }
    }
}
