﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MemoryArchiveService.Application.Abstractions;
using MemoryArchiveService.Application.DTOs;
using MemoryArchiveService.Infrastructure.Persistence;

namespace MemoryArchiveService.Infrastructure.Services;

public sealed class MediaReadStore : IMediaReadStore
{
    private readonly MemoryArchiveDbContext _db;

    public MediaReadStore(MemoryArchiveDbContext db) => _db = db;

    public async Task<MediaFileDto?> GetByIdAsync(Guid id, CancellationToken ct)
    {
        var e = await _db.MediaFiles
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id, ct);

        if (e is null)
            return null;

        return new MediaFileDto
        {
            Id = e.Id,
            MemoryId = e.MemoryId,
            FileName = e.FileName,
            Url = e.Url,
            StorageUrl = e.StorageUrl,
            MediaType = e.MediaType.ToString(),   
            Size = e.Size,
            UploadedAt = e.UploadedAt,
            CreatedAt = e.CreatedAt
        };
    }
}
