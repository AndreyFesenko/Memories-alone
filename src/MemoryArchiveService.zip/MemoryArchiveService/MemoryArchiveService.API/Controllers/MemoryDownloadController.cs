﻿// src\MemoryArchiveService\MemoryArchiveService.API\Controllers\MemoryDownloadController.cs

using System.IO.Compression;
using System.Net;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MemoryArchiveService.API.Controllers;

[ApiController]
[Route("memory/api/memory")]
public class MemoryDownloadController : ControllerBase
{
    private readonly IMemoryRepository _repo;
    private readonly IAmazonS3 _s3;
    private readonly S3Options _s3Options;

    public MemoryDownloadController(IMemoryRepository repo, IAmazonS3 s3, S3Options s3Options)
    {
        _repo = repo;
        _s3 = s3;
        _s3Options = s3Options;
    }

    // GET /memory/api/memory/user/{userId}/zip?accessLevel=&page=1&pageSize=50
    [HttpGet("user/{userId:guid}/zip")]
    [Authorize]
    public async Task<IActionResult> DownloadZipByUser(
        Guid userId,
        [FromQuery] string? accessLevel = null,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        CancellationToken ct = default)
    {
        var paged = await _repo.ListMemoriesByOwnerAsync(userId, accessLevel, page, pageSize, ct);

        Response.ContentType = "application/zip";
        var fileName = $"memories_{userId}_{DateTime.UtcNow:yyyyMMdd_HHmmss}.zip";
        Response.Headers.ContentDisposition = $"attachment; filename=\"{fileName}\"";
        Response.StatusCode = (int)HttpStatusCode.OK;

        await using var responseStream = Response.Body;
        using var archive = new ZipArchive(responseStream, ZipArchiveMode.Create, leaveOpen: true);

        var index = 1;
        foreach (var mem in paged.Items)
        {
            var safeTitle = Sanitize(mem.Title) ?? "memory";
            foreach (var mf in mem.MediaFiles ?? Enumerable.Empty<MediaFile>())
            {
                ct.ThrowIfCancellationRequested();

                var ext = Path.GetExtension(mf.FileName ?? string.Empty);
                if (string.IsNullOrWhiteSpace(ext))
                    ext = GuessExtensionByMediaType(mf.MediaType);
                var safeName = Sanitize(Path.GetFileNameWithoutExtension(mf.FileName) ?? mf.Id.ToString());
                var zipPath = $"{safeTitle}/{index:D3}_{safeName}{ext}";

                var key = GetObjectKey(mf);
                if (string.IsNullOrEmpty(key))
                {
                    await AddByHttpDownloadAsync(archive, zipPath, mf.Url, ct);
                }
                else
                {
                    await AddByS3Async(archive, zipPath, key, ct);
                }

                index++;
            }
        }

        return new EmptyResult();
    }

    private async Task AddByS3Async(ZipArchive archive, string zipPath, string key, CancellationToken ct)
    {
        var req = new GetObjectRequest
        {
            BucketName = _s3Options.Bucket,
            Key = key
        };

        using var obj = await _s3.GetObjectAsync(req, ct);
        var entry = archive.CreateEntry(zipPath, CompressionLevel.Fastest);
        await using var entryStream = entry.Open();
        await obj.ResponseStream.CopyToAsync(entryStream, ct);
    }

    private static async Task AddByHttpDownloadAsync(ZipArchive archive, string zipPath, string? url, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            var note = archive.CreateEntry(zipPath + ".failed.txt");
            await using var w = new StreamWriter(note.Open());
            await w.WriteAsync("No URL or key to fetch.");
            return;
        }

        using var http = new HttpClient();
        using var resp = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
        if (!resp.IsSuccessStatusCode)
        {
            var note = archive.CreateEntry(zipPath + ".failed.txt");
            await using var w = new StreamWriter(note.Open());
            await w.WriteAsync($"HTTP {(int)resp.StatusCode}: {resp.ReasonPhrase}");
            return;
        }

        var entry = archive.CreateEntry(zipPath, CompressionLevel.Fastest);
        await using var entryStream = entry.Open();
        await using var s = await resp.Content.ReadAsStreamAsync(ct);
        await s.CopyToAsync(entryStream, ct);
    }

    private static string Sanitize(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return "untitled";
        var s = name.Trim();
        foreach (var c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
        return s.Length > 80 ? s[..80] : s;
    }

    private static string GuessExtensionByMediaType(string? mediaType) =>
        (mediaType?.ToLowerInvariant()) switch
        {
            "image" => ".jpg",
            "video" => ".mp4",
            "audio" => ".mp3",
            "document" => ".pdf",
            _ => ""
        };

    private string? GetObjectKey(MediaFile mf)
    {
        if (!string.IsNullOrWhiteSpace(mf.StorageUrl))
            return mf.StorageUrl;

        var url = mf.Url ?? string.Empty;
        var marker = $"{_s3Options.Bucket}/";
        var i = url.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (i >= 0)
            return url[(i + marker.Length)..];

        return null;
    }
}

// Примеры контрактов — замени на свои реальные типы
public record MediaFile
{
    public Guid Id { get; init; }
    public string? FileName { get; init; }
    public string? Url { get; init; }
    public string? StorageUrl { get; init; }
    public string MediaType { get; init; } = "Image";
}

public interface IMemoryRepository
{
    Task<PagedResult<MemoryDto>> ListMemoriesByOwnerAsync(Guid ownerId, string? accessLevel, int page, int pageSize, CancellationToken ct);
}

public record PagedResult<T>(IReadOnlyList<T> Items, int TotalCount, int Page, int PageSize);

public record MemoryDto
{
    public Guid Id { get; init; }
    public string? Title { get; init; }
    public IReadOnlyList<MediaFile>? MediaFiles { get; init; }
}

public record S3Options
{
    public string Bucket { get; init; } = "memories-media";
    public string? ServiceUrl { get; init; }
    public string? PublicBaseUrl { get; init; }
}
