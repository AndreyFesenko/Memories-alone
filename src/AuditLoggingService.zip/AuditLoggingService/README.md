# AuditLoggingService

- API
- Application
- Domain
- Infrastructure
# AuditLoggingService

- API
- Application
- Domain
- Infrastructure
