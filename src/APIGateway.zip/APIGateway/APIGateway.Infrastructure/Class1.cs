﻿namespace APIGateway.Infrastructure;

public class Class1
{

}
