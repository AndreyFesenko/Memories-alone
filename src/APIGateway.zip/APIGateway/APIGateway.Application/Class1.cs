﻿namespace APIGateway.Application;

public class Class1
{

}
