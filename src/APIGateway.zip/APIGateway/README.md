# APIGateway

- API
- Application
- Domain
- Infrastructure
# APIGateway

- API
- Application
- Domain
- Infrastructure
