﻿namespace APIGateway.Domain;

public class Class1
{

}
