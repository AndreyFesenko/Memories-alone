﻿namespace NotificationService.Application;
public class ApplicationAssemblyReference { }